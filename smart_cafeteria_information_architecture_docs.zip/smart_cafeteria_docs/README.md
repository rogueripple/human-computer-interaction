# Smart Cafeteria Ordering App – Documentation

## Information Architecture Lead

This documentation contains the information architecture, navigation structure, and task flows for the Smart Cafeteria Ordering Mobile App.

### Role Responsibilities
The Information Architecture Lead organizes application content, defines the navigation structure, maps relationships between screens, and ensures that users can complete important tasks through clear and logical flows.

### Main User Tasks
1. Browse cafeteria meals.
2. View meal details and prices.
3. Customize and select a meal.
4. Add a meal to the cart.
5. Confirm an order.
6. Track preparation and collection status.

### Documentation
- [Information Architecture](information-architecture.md)
- [Navigation Structure](navigation-structure.md)
- [Task Flows](task-flows.md)
