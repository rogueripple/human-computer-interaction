# Navigation Structure

## Smart Cafeteria Ordering Mobile App

### Primary Navigation

The proposed primary navigation contains:
- Home
- Menu
- Orders
- Profile

The Cart is available from the ordering process and should remain easy to access while selecting meals.

### Navigation Map

```text
                    HOME
                      |
          +-----------+-----------+
          |           |           |
        MENU        ORDERS      PROFILE
          |
      CATEGORIES
          |
       MEAL LIST
          |
     MEAL DETAILS
          |
    CUSTOMIZE MEAL
          |
       ADD TO CART
          |
         CART
          |
   ORDER CONFIRMATION
          |
    ORDER TRACKING
       /       \
PREPARING   READY FOR
            COLLECTION
```

### Screen Relationships

| Screen | Main Destination |
|---|---|
| Home | Menu, Orders, Profile |
| Menu | Categories and Meal List |
| Meal List | Meal Details |
| Meal Details | Customize Meal |
| Customize Meal | Cart |
| Cart | Order Confirmation |
| Order Confirmation | Order Tracking |
| Orders | Current Order / Order History |
| Order Tracking | Preparing / Ready for Collection |
| Profile | Account information |

### Navigation Rules
1. Users should always know their current location in the app.
2. Back navigation should return users to the previous relevant screen.
3. Primary navigation should remain consistent.
4. Buttons should clearly describe the action they perform.
5. Ordering steps should follow a logical sequence.
