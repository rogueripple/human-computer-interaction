# Information Architecture

## Smart Cafeteria Ordering Mobile App

### 1. Purpose
The information architecture organizes the app's content and features into a clear structure so students and staff can easily find meals, place orders, and track their orders.

### 2. Main Sections

| Section | Main Content |
|---|---|
| Home | Welcome message, featured meals, quick access to menu and orders |
| Menu | Meal categories, meals, prices, availability |
| Meal Details | Meal description, price, options and customization |
| Cart | Selected meals, quantities, prices and order total |
| Order Confirmation | Order summary and confirmation |
| Order Tracking | Preparation status and collection status |
| Orders | Current and previous orders |
| Profile | User information and account settings |

### 3. Hierarchical Structure

Home
- Menu
  - Categories
    - Meal List
      - Meal Details
        - Customize Meal
          - Add to Cart
- Cart
  - Order Summary
    - Confirm Order
- Orders
  - Current Order
    - Track Preparation
    - Ready for Collection
  - Order History
- Profile

### 4. Information Organization Principles
- Related information is grouped together.
- Important actions are easy to find.
- Navigation remains consistent between screens.
- Meal information is presented before ordering decisions.
- Order status is separated from browsing and ordering functions.
- The structure supports simple mobile navigation and touch interaction.
