# Task Flows

## Smart Cafeteria Ordering Mobile App

The prototype must demonstrate complete user scenarios. The following task flows define the main interactions.

## Scenario 1: Browse and Select a Meal

```text
Home
  ↓
Menu
  ↓
Select Category
  ↓
Meal List
  ↓
Meal Details
```

### Goal
The user finds a meal and views its details and price before deciding whether to order it.

---

## Scenario 2: Customize and Place an Order

```text
Home
  ↓
Menu
  ↓
Meal List
  ↓
Meal Details
  ↓
Customize Meal
  ↓
Add to Cart
  ↓
Cart
  ↓
Order Confirmation
```

### Goal
The user selects a meal, customizes it, reviews the order and confirms the order.

---

## Scenario 3: Track an Order

```text
Home
  ↓
Orders
  ↓
Current Order
  ↓
Order Tracking
  ↓
Preparing
  ↓
Ready for Collection
```

### Goal
The user checks the progress of an existing order and knows when it is ready for collection.

---

## Information Architecture Lead Checklist

- [x] Define main application sections
- [x] Organize related information
- [x] Define primary navigation
- [x] Map screen relationships
- [x] Create three complete task flows
- [ ] Connect the final Balsamiq screens
- [ ] Review navigation after usability testing
- [ ] Update the structure based on user feedback
